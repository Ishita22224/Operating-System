#include <iostream>
#include <list>
#include <functional>
#include <stdlib.h>
#include <cstring>
#include <vector>
#include <chrono>
#include <pthread.h>
#include <tuple>

using namespace std;

// void* thread_wrapper(void* arg) {
//   thread_args* args = (thread_args*)arg;
//   args->func(args->arg);
//   delete args;
//   return NULL;
// }

//error check func for pthread 1
void create_thread(pthread_t* thread, const pthread_attr_t* attr, void* (*start_routine)(void*), void* arg) {
  int error = pthread_create(thread, attr, start_routine, arg);
  if (error != 0) {
      cerr << "Error creating thread: " << strerror(error) << endl;
      exit(EXIT_FAILURE);
  }
}

//error check for pthread 2 
void join_thread(pthread_t thread, void** retval) {
  int error = pthread_join(thread, retval);
  if (error != 0) {
      cerr << "Error joining thread: " << strerror(error) << endl;
      exit(EXIT_FAILURE);
  }
}


//helper func for 1D
void* parallel_for_worker(void* arg) {
  auto params = static_cast<tuple<int, int, function<void(int)>, int>*>(arg);
  int low = get<0>(*params);
  int high = get<1>(*params);
  function<void(int)> lambda = get<2>(*params);
  int thread_id = get<3>(*params);

  // Execute the lambda function
  for (int i = low; i < high; ++i) {
      lambda(i);
  }

  pthread_exit(nullptr);
}

// helper func for 2D
void* parallel_for_2D_worker(void* arg) {
  auto params = static_cast<tuple<int, int, int, int, function<void(int, int)>, int>*>(arg);
  int l1 = get<0>(*params);
  int h1 = get<1>(*params);
  int l2 = get<2>(*params);
  int h2 = get<3>(*params);
  function<void(int, int)> lambda = get<4>(*params);


  // Execute the lambda function
  for (int i = l1; i < h1; ++i) {
      for (int j = l2; j < h2; ++j) {
          lambda(i, j);
      }
  }

  pthread_exit(nullptr);
} 





// void parallel_for(int low, int high, function<void(int)> &&lambda, int numThreads) {
//   threads = new pthread_t[numThreads];
//   this->numThreads = numThreads;

//   clock_t start = clock();

//   for (int i = 0; i < numThreads; i++) {
//     int chunk_size = (high - low) / numThreads + 1;
//     int start_index = i * chunk_size;
//     int end_index = min((i + 1) * chunk_size, high);

//     thread_args* args = new thread_args;
//     args->func = [&lambda, start_index, end_index](void* arg) {
//       for (int j = start_index; j < end_index; j++) {
//         lambda(j);
//       }
//     };
//     args->arg = NULL;

//     pthread_create(&threads[i], NULL, thread_wrapper, args);
//   }

//   for (int i = 0; i < numThreads; i++) {
//     pthread_join(threads[i], NULL);
//   }

//   delete[] threads;
//   clock_t end = clock();
//   double time_taken = (double)(end - start) / CLOCKS_PER_SEC;
//   cout << "Total execution time: " << time_taken << " seconds" << endl;
// }




// Parallel_for func for 1D range
void parallel_for(int low, int high, function<void(int)> &&lambda, int numThreads) {
  vector<pthread_t> threads(numThreads);
  vector<tuple<int, int, function<void(int)>, int>> params(numThreads);

  auto start_time = chrono::high_resolution_clock::now();

  //thread creating and distribution 
  for (int i = 0; i < numThreads; ++i) {
    params[i] = make_tuple(low + i * (high - low) / numThreads, low + (i + 1) * (high - low) / numThreads, lambda, i);

    create_thread(&threads[i], nullptr, parallel_for_worker, &params[i]);

  }

  //waiting 
  for (int i = 0; i < numThreads; ++i) {
    join_thread(threads[i], nullptr);
  }

  auto end_time = chrono::high_resolution_clock::now();
  auto duration = chrono::duration_cast<chrono::microseconds>(end_time - start_time).count();
  cout << "Parallel_for exec time: " << duration << " ms\n";
}



// void parallel_for(int low1, int high1, int low2, int high2,
//                   function<void(int, int)> &&lambda, int numThreads) {
//   threads = new pthread_t[numThreads];
//   this->numThreads = numThreads;

//   clock_t start = clock();

//   for (int i = 0; i < numThreads; i++) {
//     int chunk_size1 = (high1 - low1) / numThreads + 1;
//     int start_index1 = i * chunk_size1;
//     int end_index1 = min((i + 1) * chunk_size1, high1);

//     int chunk_size2 = (high2 - low2) / numThreads + 1;
//     int start_index2 = i * chunk_size2;
//     int end_index2 = min((i + 1) * chunk_size2, high2);

//     thread_args* args = new thread_args;
//     args->func = [&lambda, start_index1, end_index1, start_index2, end_index2](void* arg) {
//       for (int j = start_index1; j < end_index1; j++) {
//         for (int k = start_index2; k < end_index2; k++) {
//           lambda(j, k);
//         }
//       }
//     };
//     args->arg = NULL;

//     pthread_create(&threads[i], NULL, thread_wrapper, args);
//   }

//   for (int i = 0; i < numThreads; i++) {
//     pthread_join(threads[i], NULL);
//   }

//   delete[] threads;
//   clock_t end = clock();
//   double time_taken = (double)(end - start) / CLOCKS_PER_SEC;
//   cout << "Total execution time: " << time_taken << " seconds" << endl;
// }







// Parallel_for funct for 2D
void parallel_for(int low1, int high1, int low2, int high2, function<void(int, int)> &&lambda, int numThreads) {
  vector<pthread_t> threads(numThreads);
  vector<tuple<int, int, int, int, function<void(int, int)>, int>> params(numThreads);

  auto start_time = chrono::high_resolution_clock::now();

  // thread creating and distribution
  for (int i = 0; i < numThreads; ++i) {
    params[i] = make_tuple(low1 + i * (high1 - low1) / numThreads, low1 + (i + 1) * (high1 - low1) / numThreads, low2, high2, lambda, i);

    create_thread(&threads[i], nullptr, parallel_for_2D_worker, &params[i]);
  }

  // Waiting
  for (int i = 0; i < numThreads; ++i) {
    join_thread(threads[i], nullptr);
  }

  auto end_time = chrono::high_resolution_clock::now();
  auto duration = chrono::duration_cast<chrono::microseconds>(end_time - start_time).count();
  cout << "Parallel_for_2D exec time: " << duration << " ms\n";
}



int user_main(int argc, char **argv);

/* Demonstration on how to pass lambda as parameter.
 * "&&" means r-value reference. You may read about it online.
 */
void demonstration(function<void()> && lambda) {
  lambda();
}

int main(int argc, char **argv) {
  /* 
   * Declaration of a sample C++ lambda function
   * that captures variable 'x' by value and 'y'
   * by reference. Global variables are by default
   * captured by reference and are not to be supplied
   * in the capture list. Only local variables must be 
   * explicity captured if they are used inside lambda.
   */
  int x=5,y=1;
  // Declaring a lambda expression that accepts void type parameter
  auto /*name*/ lambda1 = /*capture list*/[/*by value*/ x, /*by reference*/ &y](void) {
    /* Any changes to 'x' will throw compilation error as x is captured by value */
    y = 5;
    cout<<"====== Welcome to Assignment-"<<y<<" of the CSE231(A) ======\n";
    /* you can have any number of statements inside this lambda body */
  };
  // Executing the lambda function
  demonstration(lambda1); // the value of x is still 5, but the value of y is now 5

  int rc = user_main(argc, argv);
 
  auto /*name*/ lambda2 = [/*nothing captured*/]() {
    cout<<"====== Hope you enjoyed CSE231(A) ======\n";
    /* you can have any number of statements inside this lambda body */
  };
  demonstration(lambda2);
  return rc;
}

#define main user_main


