#include "loader.h"


Elf32_Ehdr *ehdr;
Elf32_Phdr *phdr;
int fd;

/*
 * release memory and other cleanups
 */
void loader_cleanup() {
  if (fd != -1)
    close(fd);
  free(ehdr);
  free(phdr);
  
}

/*
 * Load and run the ELF executable file
 */
void load_and_run_elf(char** argv) {
  fd = open(argv[1], O_RDONLY);
  if (fd == -1) {
    perror("open");
    return;
  }
  // Read ELF header
  ehdr = (Elf32_Ehdr *)malloc(sizeof(Elf32_Ehdr));
  if (read(fd, ehdr, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr)) {
    perror("read");  
    loader_cleanup();
    return;
  }

  // Find and load the PT_LOAD segment containing the entry point

  //phdr = (Elf32_Phdr *) malloc(sizeof(Elf32_Phdr) * ehdr->e_phnum);
    
    
  // Read program headers
  phdr = (Elf32_Phdr*)malloc(ehdr->e_phentsize);
  int flag=-1;
  for(unsigned int i=1;i<ehdr->e_phnum;i++)
  {
    lseek(fd, ehdr->e_phoff+(i*ehdr->e_phentsize), SEEK_SET);

    if (read(fd, phdr, ehdr->e_phentsize) != ehdr->e_phentsize) {
        perror("read");
        loader_cleanup();
        return;
    }
    if(phdr->p_type == PT_LOAD){flag=0;break;}
  
  }

  if(flag==-1){
    printf("No PT_LOAD segment with entry point found.\n");
    loader_cleanup();
  }

  void * virtual_mem;
  virtual_mem = mmap(NULL, phdr->p_memsz, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_ANONYMOUS|MAP_PRIVATE, 0,0);
  if (virtual_mem == MAP_FAILED)
  {
    perror("mmap");
    loader_cleanup();
    return;
  }
  lseek(fd, phdr->p_offset, SEEK_SET);
  read(fd,virtual_mem, phdr->p_memsz);
  
  unsigned int virtual_start = phdr->p_vaddr;
  
  void* entry_point_offset = (void*)(ehdr->e_entry - virtual_start);

  int (*_start)() = (int (*)())((uintptr_t)virtual_mem + (uintptr_t)entry_point_offset);

  int return_val = _start();

  printf("%d\n", return_val);
  munmap(virtual_mem, phdr->p_memsz);
  



  // 1. Load entire binary content into the memory from the ELF file.
  // 2. Iterate through the PHDR table and find the section of PT_LOAD 
  //    type that contains the address of the entrypoint method in fib.c
  // 3. Allocate memory of the size "p_memsz" using mmap function 
  //    and then copy the segment content
  // 4. Navigate to the entrypoint address into the segment loaded in the memory in above step
  // 5. Typecast the address to that of function pointer matching "_start" method in fib.c.
  // 6. Call the "_start" method and print the value returned from the "_start"
  // int result = _start();
  // printf("User _start return value = %d\n",result);
}

int main(int argc, char** argv) 
{
  if(argc != 2) {
    printf("Usage: %s <ELF Executable> \n",argv[0]);
    exit(1);
  }
  // 1. carry out necessary checks on the input ELF file
  // 2. passing it to the loader for carrying out the loading/execution
  load_and_run_elf(argv);
  // 3. invoke the cleanup routine inside the loader  
  loader_cleanup();
  return 0;
}
