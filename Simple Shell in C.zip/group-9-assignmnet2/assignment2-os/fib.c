#include<stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <stdlib.h>

int fib(int n) {
    if (n == 0 || n == 1) {
        return n;
    }

    return fib(n-1) + fib(n-2);
}

int main(int argc, char *argv[]) {
    
    printf("%d\n\n" , fib(atoi(argv[1])));

}
