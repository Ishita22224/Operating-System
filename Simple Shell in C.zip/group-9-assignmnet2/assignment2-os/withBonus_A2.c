#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <time.h>
#include <dirent.h> 

// Structure to save the Details related to a command
struct Node {
    clock_t start;
    clock_t end;
    char command[100];  
    double duration;
    int pid;
};

struct Node history[50];
int numm = 0;

// Checking Input
int readable(char a){
    if(isalnum(a) || a == '.' || a == '/' || a == '?'
                || a == '-' || a == '_' || a == ' ' || a == '&') return 1;
    else return 0;

}

// Function to print 'echo' command
int launchEcho(char *words[100], int count) {
    int status = fork();

    if (status == 0) {

        // checks input validity
        if(!readable(words[1][0])){
            printf("Nothing Entered after echo\n");
            return -1;
        }
        
        char fullstring[1000]={'\0'};        
        for(int i=1; i<count;i++){
            if(i==count-1){
                int j=0;    
                while(readable(words[i][j])) {
                    j++;
                }
                words[i][j]='\0';
            }
            if(i==1){
                strcat(fullstring, words[i]);
                continue;    
            }    
            
            strcat(fullstring, " ");
            strcat(fullstring, words[i]);
            
        }

        // execution of command echo
        if (execlp("echo", "echo", fullstring , NULL) == -1) {
            perror("Execution of the Function Failed");
            return -1;
        } else {
            return 1;
        }
        
    } else if (status < 0) {
        perror("Fork Fails");
        return -1;
    } else {
        wait(NULL);
    }
}

// for executing all the rest of commands on the shell
int defaultLaunch(char *words[100], int count) {
    int status = fork();

    if (status == 0) {        
        char fullstring[1000]={'\0'};
        
        for(int i=0; i<count;i++){
            if(i==count-1){
                int j=0;    
                while(readable(words[i][j])) {
                    j++;
                }
                words[i][j]='\0';
            }
            if(i==0){
                strcat(fullstring, words[i]);
                continue;    
            }    
            
            strcat(fullstring, " ");
            strcat(fullstring, words[i]);
            
        }

        // executes the rest of commands using /bin/sh
        if (execlp("/bin/sh", "sh", "-c", fullstring, NULL) == -1) {
            perror("Execution of the Function Failed");
            return -1;
        } else {
            return 1;
        }
        
    } else if (status < 0) {
        perror("Fork Fails");
        return -1;
    } else {
        wait(NULL);
    }
}

// Bonus Part: implementation of '&' in shell
int backgroundLaunch(char *words[100], int count) {
    int status = fork();
    if (status == 0) {
        
        char fullstring[1000]={'\0'};
        
        for(int i=0; i<count;i++){
            if(i==count-1){
                int j=0;    
                while(readable(words[i][j])) {
                    j++;
                }
                words[i][j]='\0';
            }
            if(i==0){
                strcat(fullstring, words[i]);
                continue;    
            }    
            
            strcat(fullstring, " ");
            strcat(fullstring, words[i]);
            
        }
        printf("[1] %d\n", getpid());

        // executes the command
        if (execlp("/bin/sh", "sh", "-c", fullstring, NULL) == -1) {
            perror("Execution of the Function Failed");
            return -1;
        } else {
            return 1;
        }
        
    } else if (status < 0) {
        perror("Fork Fails");
        return -1;
    }
    else{
        wait(NULL);
    }
}

// executes all the functions given in the test case
int launch(char *words[100], int count) {
    int status = fork();

    if (status == 0) {
        for(int i=0;i<count;i++){
            if(i==count-1){
                int j=0;    
                while(readable(words[i][j])) {
                    j++;
                }
                words[i][j]='\0';
            }
        }
        words[count]=NULL;
        
        // executing the commands using execvp function 
        if (execvp(words[0], words) == -1) {
            perror("Execution of the Function Failed");
            return -1;
        } else {
            return 1;
        }
        
    } else if (status < 0) {
        perror("Fork Fails");
        return -1;
    } else {
        wait(NULL);
    }
}

// prints all the history of commands executed (name only )
void History(int end) {
    double secForStart;
    double secForEnd;
    for (int i=0; i<numm; i++) {

        // converting start time and end time to appropriate data type
        secForStart = (double) history[i].start/CLOCKS_PER_SEC;
        secForEnd = (double) history[i].end/CLOCKS_PER_SEC;

        // prints name of the command, starting time, ending time, duration of exectution and process id of each command
        if(end == 1) printf("\nName : %s", history[i].command);
        else printf(" %d  %s", history[i].pid, history[i].command);
        fflush(stdout);
    }
}
// prints all the history of commands executed before exiting from the program
void getHistory(int end) {
    double secForStart;
    double secForEnd;
    for (int i=0; i<numm; i++) {

        // converting start time and end time to appropriate data type
        secForStart = (double) history[i].start/CLOCKS_PER_SEC;
        secForEnd = (double) history[i].end/CLOCKS_PER_SEC;

        // prints name of the command, starting time, ending time, duration of exectution and process id of each command
        if(end == 1) printf("\nName : %s\t\t\t\tStart Time : %f\tEnd Time : %f\tDuration : %f, PID: %d", history[i].command, secForStart, secForEnd, history[i].duration, history[i].pid);
        else printf(" %d  %s", history[i].pid, history[i].command);
        fflush(stdout);
    }
}


// calls respective functions to execute the commands
int getCommand(char command[])
{   
    if (strcmp(command, "history\n") == 0) {
        History(1);
        return 0;
    }


    // splits the command into different words
    int count = 0;

    char *words[100];
    char *token = strtok(command, " ");

    while (token != NULL) {
        words[count] = token;
        count++;
        token = strtok(NULL, " ");
    }


    // checks for the command entered and calls the respective function
    if(words[count-1][0] == '&'){
        return backgroundLaunch(words, count);
    }
    else if(strcmp(words[0], "history\n") == 0 || strcmp(words[0], "history")==0){
        getHistory(0);
        return (int)getpid();
    }    
    else if(strcmp(words[0], "ls\n") == 0) {
        return launch(words, count);
    }
    else if(strcmp(words[0], "ls") == 0) {
        return launch(words, count);
    }
    else if(strcmp(words[0], "wc") == 0) {
        return launch(words,count);
    }
    else if(strcmp(words[0], "echo") == 0) {
        return launchEcho(words, count);
    }
    else if(strcmp(words[0], "grep") == 0) {
        return launch(words, count);
    }
    else if(words[0][0] == '.' && words[0][1] == '/') {
        return launch(words, count);
    }
    else if(strcmp(words[0], "sort") == 0) {
        return launch(words, count);
    }
    else if(strcmp(words[0], "uniq") == 0) {
        return launch(words, count);
    }
    else{
        return defaultLaunch(words, count);
    }
}

// runs an infinite loop to take input and call for execution of these commands
// also keeps track of list of commands
void shell_loop()
{
    do
    {
        printf("iiitd@possum:~$ ");

        // input for command
        char command[100];
        fgets(command, 100, stdin);

    
        struct Node comm;
        strcpy(comm.command, command);
        clock_t st, ed;
        double duration;

        st = clock();
        int pid = getCommand(command);
        ed = clock();

        // storing the information in a struct node command and adding to a list of commands.

        comm.start = st;
        comm.end = ed;    
        duration = ((double) (ed - st)) / CLOCKS_PER_SEC;

        comm.duration = duration;
        comm.pid = pid;

        history[numm] = comm;
        numm++;

    } while (1);
}


// changes the default action of the ctrl + c signal
static void my_handler(int signum) {
    if (signum == SIGINT) {

        // prints history as soon as we press ctrl+c
        getHistory(1);
        exit(0);
    }
}

int main()
{
    struct sigaction sig;
    memset(&sig, 0, sizeof(sig));
    sig.sa_handler = my_handler;
    sigaction(SIGINT, &sig, NULL);
    shell_loop();
}

