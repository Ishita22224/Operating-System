#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <signal.h>
#include <sys/stat.h>
#include <syslog.h>


#define MIN(a, b) ((a) < (b) ? (a) : (b))

// scheduler runs using given time slice and ncpu


static void logger(char str[100]){
   FILE * file = fopen("/mnt/c/Users/91989/Documents/ass_3_os/log.txt", "a");
   fprintf(file, "%s\n", str);
   fflush(file);
   fclose(file);
}
int daemon_running = 0;
int numm=0;


struct Node {
    char name[100];
    volatile int id;
    volatile int pid;
    volatile int priority;
    volatile clock_t exec_time;
    volatile clock_t wait_time;
    volatile clock_t exec_wait_time;
    volatile clock_t last_stop;
    
} dummy;

struct Queue {
    volatile int  size;
    volatile int cur_size;
    volatile int front;
    volatile int rear;
    volatile int total;
    struct Node* arr[100];
    volatile int n_cpu;
    volatile double t_slice;
    volatile int running;
};
struct Queue* scheduling_queue;

struct Node history[100];

// functions of queue
int isEmpty(struct Queue *scheduling_queue) {
    return (scheduling_queue->cur_size == 0);
}

int isFull(struct Queue *scheduling_queue) {
    return (scheduling_queue->cur_size == scheduling_queue->size);
}
struct Node* scheduler_enqueue(struct Node* com, struct Queue *scheduling_queue) {
    
    if (isFull(scheduling_queue)) {
        printf("This queue is full");
        return &dummy;
    } else {
        scheduling_queue->rear = (scheduling_queue->rear + 1)
                  % scheduling_queue->size;
        strcpy(scheduling_queue->arr[scheduling_queue->rear]->name, com->name);

        scheduling_queue->arr[scheduling_queue->rear]->last_stop = com->last_stop;
        scheduling_queue->arr[scheduling_queue->rear]->exec_wait_time = com->exec_wait_time;
        scheduling_queue->arr[scheduling_queue->rear]->wait_time =com->wait_time; 
        scheduling_queue->arr[scheduling_queue->rear]->pid =com->pid; 
        scheduling_queue->arr[scheduling_queue->rear]->id =com->id; 
        
        scheduling_queue->cur_size++;
    }
    return scheduling_queue->arr[scheduling_queue->rear];
}

void createQ(struct Queue *scheduling_queue){

    scheduling_queue->size = 100;
    scheduling_queue->front = scheduling_queue->cur_size = 0;
    scheduling_queue->rear = scheduling_queue->size-1;
    scheduling_queue->running=0;
    
}
void merge(struct Node arr[], int l, int m, int r) 
{ 
    int i, j, k; 
    int n1 = m - l + 1; 
    int n2 = r - m; 
  
    // Create temp arrays 
    struct Node L[n1], R[n2]; 
  
    // Copy data to temp arrays 
    // L[] and R[] 
    for (i = 0; i < n1; i++) 
        L[i] = arr[l + i]; 
    for (j = 0; j < n2; j++) 
        R[j] = arr[m + 1 + j]; 
  
    // Merge the temp arrays back 
    // into arr[l..r] 
    // Initial index of first subarray 
    i = 0; 
  
    // Initial index of second subarray 
    j = 0; 
  
    // Initial index of merged subarray 
    k = l; 
    while (i < n1 && j < n2) { 
        if (L[i].priority >= R[j].priority) { 
            arr[k] = L[i]; 
            i++; 
        } 
        else { 
            arr[k] = R[j]; 
            j++; 
        } 
        k++; 
    } 
  
    // Copy the remaining elements 
    // of L[], if there are any 
    while (i < n1) { 
        arr[k] = L[i]; 
        i++; 
        k++; 
    } 
  
    // Copy the remaining elements of 
    // R[], if there are any 
    while (j < n2) { 
        arr[k] = R[j]; 
        j++; 
        k++; 
    } 
} 
  
// l is for left index and r is 
// right index of the sub-array 
// of arr to be sorted 
void mergeSort(struct Node* arr[], int l, int r) 
{   
    printf("LOL");
    fflush(stdout);
    if (l < r) { 
        // Same as (l+r)/2, but avoids 
        // overflow for large l and h 
        int m = l + (r - l) / 2; 
  
        // Sort first and second halves 
        mergeSort(arr, l, m); 
        mergeSort(arr, m + 1, r); 
  
        merge(arr, l, m, r); 
    } 
} 


struct Node* scheduler_dequeue(struct Queue *scheduling_queue) {
    
    if (isEmpty(scheduling_queue)) {
        printf("the Queue is empty");
    } else {
        // sort
        mergeSort(scheduling_queue->arr, scheduling_queue->front, scheduling_queue->rear);
        //dequeue 
        struct Node* proc = scheduling_queue->arr[scheduling_queue->front];
        scheduling_queue->front = (scheduling_queue->front + 1)
                   % scheduling_queue->size;
        scheduling_queue->cur_size--;
        return proc;
    }
    return &dummy;
}




struct Node* execute_process(struct Node* p)
{

    pid_t child_pid;
    clock_t start, end;
    start = clock();

    p->exec_wait_time = 0;
    // Create a child process
    child_pid = fork();

    if (child_pid == -1) {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if (child_pid == 0) {

        chdir("/mnt/c/Users/91989/Documents/ass_3_os/");
        // This is the child process
        // Replace this with the code you want to measure the execution time of

        // For example, you can run a command using exec
        char *args[]={p->name,NULL};

        execvp(args[0],args);
        perror("exec failed");
        exit(EXIT_FAILURE);
    } else {
        // This is the parent process

        // Get the start time
        
        char s[100];

        p->pid = child_pid;
        // Wait for the child process to finish
        int status;
        p->pid = waitpid(child_pid, &status, 0);

        // Get the end time
        end = clock();

        
        // Calculate and print the execution time
       p->exec_wait_time = (end - start);

       sprintf(s, "INFO For Process : %s", p->name);
       logger(s);
       sprintf(s, "Exec Time For Process : %lu clocks\n", p->exec_wait_time - p->wait_time);
       logger(s);

    key_t key = 5732; 
    int shmid = shmget(key,100*sizeof(struct Node),0666|IPC_CREAT);
    if(shmid==-1){
        perror("ds");
        exit(0);
    }
    struct Node* history = (struct Node*) shmat(shmid,(void*)0,0);

    history[p->id] = *p;
    shmdt(history);
       return p;
    }
}



static void run_daemon(){


    /* On success: The child process becomes session leader */
    if (setsid() < 0)
        exit(EXIT_FAILURE);
    


    /* Catch, ignore and handle signals */
    /*TODO: Implement a working signal handler */
    signal(SIGCHLD, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    pid_t pid;
    
    /* Fork off for the second time*/
    pid = fork();
    
    /* An error occurred */
    if (pid < 0)
        exit(EXIT_FAILURE);
    
    /* Success: Let the parent terminate */
    if (pid > 0)
        exit(EXIT_SUCCESS);
    
    /* Set new file permissions */
    umask(0);
    /* Change the working directory to the root directory */
    /* or another appropriated directory */
    chdir("/mnt/c/Users/91989/Documents/ass_3_os/");
    
    /* Close all open file descriptors */
    int x;
    for (x = sysconf(_SC_OPEN_MAX); x>=0; x--)
    {
        close (x);
    }
    
    key_t key = 5538; 
  
    // shmget returns an identifier in shmid 
    int shmid = shmget(key,sizeof(struct Queue),0666|IPC_CREAT); 

    struct Queue *scheduling_queue = (struct Queue*) shmat(shmid,(void*)0,0); 
    
    struct Queue *running_queue = (struct Queue*) malloc(sizeof(struct Queue));
    createQ(running_queue);

    running_queue->size = scheduling_queue->n_cpu;
        

    for(int i=0;i<running_queue->size;i++){
        running_queue->arr[i] = malloc(sizeof(struct Node));

    }
    //running_queue->arr = (struct Node**) malloc(running_queue->size*sizeof(struct Node*));
    running_queue->running=0;
    running_queue->total=0;

    //running_queue->arr = (struct Queue*) malloc(running_queue->size*sizeof(struct Node));
    //logger("aaja");
    while (!isEmpty(scheduling_queue))
    {


        /* code */

        char s[50];
        int sched_now = MIN(scheduling_queue->n_cpu,scheduling_queue->cur_size); 
        for (int i=0;i<sched_now;i++)
        {
            
            sprintf(s, "%s %d",scheduling_queue->arr[scheduling_queue->front]->name, scheduling_queue->front);
            logger(s);
            struct Node* p = scheduler_dequeue(scheduling_queue);
            // sprintf(s,"%lu\n", clock()-p->last_stop);
            // logger(s);
            // sprintf(s,"file name: %s ", p->name);
            // logger(s);

            p->wait_time += (clock()-p->last_stop);

            if(p->exec_wait_time==-1){
            
                p = execute_process(p);
                scheduler_enqueue(p, running_queue);

            }
            else
            {
                kill(p->pid, SIGCONT);
                scheduler_enqueue(p, running_queue);
            }
            

        }
        sleep(scheduling_queue->t_slice);

        // sprintf(s, "yaha %d", scheduling_queue->cur_size);
        // logger(s);
    
        for(int i=0;i<sched_now;i++){

            struct Node* p = scheduler_dequeue(running_queue);

            p->last_stop = clock();
            
            int status;
            pid_t return_pid = waitpid(p->pid, &status, WNOHANG); /* WNOHANG def'd in wait.h */
            if (return_pid == -1) {
                /* error */
            } else if (return_pid == 0) {
                // sprintf(s, "yaha2 %d", p->pid);
                // logger(s);
                kill(p->pid, SIGSTOP);
                scheduler_enqueue(p, scheduling_queue);
                /* child is still running */
            } else if (return_pid == p->pid) {
                /* child is finished. exit status in   status */
            }

        }
        //scheduler_dequeue(scheduling_queue);
        //syslog(LOG_INFO, "asklsa");
    }
    logger("execution done");
    
    scheduling_queue->running=0;
    shmdt(scheduling_queue);

    exit(0);
}


void shell_loop(struct Queue *scheduling_queue) {   
    while(1) {

        printf("SimpleShell$ "); 
        char command[100];
        char proces[20];
        int k=0;
        fgets(command, 100, stdin);
        
        int flag = 0;
        int pri = 0;

        for(int i=7; command[i]!='\0' ;i++)
        {   

            if(command[i]!='\n' && command[i] != ' '){
                proces[k++] = command[i];
            }

            if (command[i] == ' ') {
                flag = 1;

                if(command[i+1]!='\0') {
                    pri = command[i+1] - '0';
                    break;
                }
                
            }

        }

        proces[k] = '\0';
        
        struct Node* p = malloc(sizeof(struct Node));
        if(p == NULL){
            perror("malloc failed");
            exit(1);
        }
        
        strcpy(p->name, proces);
        
                
        p->exec_wait_time = -1;
        p->wait_time = 0; 
        p->last_stop = clock();
        p->priority = pri;
        p->id = scheduling_queue->total;
        printf("id %d\n", p->id);
        scheduling_queue->total++;

        scheduler_enqueue(p, scheduling_queue);
        
        if(!isEmpty(scheduling_queue))printf("%d %s \n", scheduling_queue->front,scheduling_queue->arr[scheduling_queue->front]->name);

        if(!isEmpty(scheduling_queue) && scheduling_queue->running!=1){

                scheduling_queue->running = 1;
                pid_t pid;

                /* Fork off the parent process */
                pid = fork();
                
                if(pid==0){
                /* An error occurred */
                if (pid < 0)
                    exit(EXIT_FAILURE);
                
                /* Success: Let the parent terminate */
                // if (pid > 0)
                //     exit(EXIT_SUCCESS);

                run_daemon();
                
            }
        }

    }
}


static void my_handler(int signum) {
    if (signum == SIGINT) {

        // prints history as soon as we press ctrl+c
    key_t key = 5732; 
    int shmid = shmget(key,100*sizeof(struct Node),0666|IPC_CREAT);
    if(shmid==-1){
        perror("ds");
        exit(0);
    }
    struct Node* history = (struct Node*) shmat(shmid,(void*)0,0);

    for(int i=0;i<scheduling_queue->total;i++){
    struct Node p = history[i];
    printf("\nINFO For Process : %s\n", p.name);

    printf("Exec Time For Process : %lu clocks\n", p.exec_wait_time - p.wait_time);
    }
        exit(0);
    }

}

int main(int argc, char *argv[]) {
    int n_cpu = atoi(argv[1]);
    double t_slice = atoi(argv[2]);

    key_t key = 5538; 
    int shmid = shmget(key,sizeof(struct Queue),0666|IPC_CREAT);
    if(shmid==-1){
        perror("ds");
        exit(0);
    }
    scheduling_queue = (struct Queue*) shmat(shmid,(void*)0,0);
    scheduling_queue->n_cpu = n_cpu;
    scheduling_queue->t_slice = t_slice;
    scheduling_queue->total=0;
    createQ(scheduling_queue);

    // key = 5126; 
    // shmid = shmget(key,100*sizeof(struct Node),0666|IPC_CREAT);
    // if(shmid==-1){
    //     perror("ds");
    //     exit(0);
    // }
    // struct Node** history = (struct Node**) shmat(shmid,(void*)0,0);

    for(int i=0;i<100;i++){
        scheduling_queue->arr[i] = malloc(sizeof(struct Node));

    }
    //scheduling_queue->arr = (struct Node*) malloc(scheduling_queue->size*sizeof(struct Node));
    // struct Queue running_queue;
    // running_queue.size = n_cpu;
    // running_queue.front = running_queue.rear = -1;
    // running_queue.arr = (struct Node*) malloc(running_queue.size*sizeof(struct Node));
    // shmat(shmid,(void*)0,0); 

    struct sigaction sig;
    memset(&sig, 0, sizeof(sig));
    sig.sa_handler = my_handler;
    sigaction(SIGINT, &sig, NULL);
    shell_loop(scheduling_queue);

    //shmdt(history);
    shmdt(scheduling_queue->arr);
    shmdt(scheduling_queue);
}

