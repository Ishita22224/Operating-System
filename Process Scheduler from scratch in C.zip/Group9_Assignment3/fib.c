#include<stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <stdlib.h>
#include "dummy_main.h"
#include <signal.h>

volatile sig_atomic_t is_running = 1;
pthread_t signal_thread;

// Signal handler for SIGSTOP
void sigstop_handler(int signum) {
    printf("Received SIGSTOP signal. Sleeping...\n");
    is_running = 0;
}

// Signal handler for SIGCONT
void sigcont_handler(int signum) {
    printf("Received SIGCONT signal. Resuming...\n");
    is_running = 1;
}

// Function for the signal handling thread
void *signal_thread_function(void *arg) {
    signal(SIGSTOP, sigstop_handler);
    signal(SIGCONT, sigcont_handler);

    while (1) {
        pause();
    }
    return NULL;
}

int main(int argc, char **argv) {
    /* You can add any code here you want to support your SimpleScheduler implementation */
    pthread_create(&signal_thread, NULL, signal_thread_function, NULL);
    int ret = dummy_main(argc, argv);
    return ret;
}

int fib(int n) {
    if (n == 0 || n == 1) {
        return n;
    }

    return fib(n-1) + fib(n-2);
}

int dummy_main(int argc, char **argv) {
    // Add your code here for the program you want to run
    // This is where the user can define their custom program logic.
    int x = fib(45);
    
    return 0; // Return an appropriate exit status.
}

#define main dummy_main






