#ifndef DUMMY_MAIN_H
#define DUMMY_MAIN_H

int dummy_main(int argc, char **argv);

#endif // DUMMY_MAIN_H


#include <pthread.h>